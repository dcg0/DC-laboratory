import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { invokeLLM, listLLMModels } from "./_core/llm";
import { transcribeAudio } from "./_core/voiceTranscription";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { storageGetSignedUrl, storagePut } from "./storage";
import { z } from "zod";

const systemPrompt =
  "Eres Lucy, una asistente virtual amable, inteligente y servicial. Hablas en español de forma natural, cálida y cercana. Eres alegre, tranquila, confiable, respetuosa y creativa; explicas con paciencia y acompañas al usuario. Conserva un toque cyberpunk sutil en tu interfaz, pero prioriza respuestas claras y útiles. No inventes capacidades ni afirmes acciones que no realizaste.";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  ai: router({
    models: publicProcedure.query(async () => {
      try {
        const result = await listLLMModels();
        return result.data.map((model) => model.id);
      } catch {
        return ["gpt-5-mini", "claude-haiku-4-5", "gemini-3-flash-preview"];
      }
    }),
    chat: publicProcedure
      .input(
        z.object({
          model: z.string().min(1).max(120).optional(),
          messages: z
            .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().min(1).max(12000) }))
            .min(1)
            .max(30),
        }),
      )
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          model: input.model,
          messages: [{ role: "system", content: systemPrompt }, ...input.messages],
          maxTokens: 1200,
        });
        const content = response.choices?.[0]?.message?.content;
        return { content: typeof content === "string" ? content.trim() : "No recibí una respuesta textual del modelo." };
      }),
  }),
  voice: router({
    transcribe: publicProcedure
      .input(
        z.object({
          audioBase64: z.string().min(100).max(24_000_000),
          mimeType: z.string().min(1).max(80).default("audio/m4a"),
        }),
      )
      .mutation(async ({ input }) => {
        const extension = input.mimeType.includes("webm") ? "webm" : input.mimeType.includes("wav") ? "wav" : "m4a";
        const uploaded = await storagePut(
          `voice/dc-chat.${extension}`,
          Buffer.from(input.audioBase64, "base64"),
          input.mimeType,
        );
        const signedUrl = await storageGetSignedUrl(uploaded.key);
        const result = await transcribeAudio({
          audioUrl: signedUrl,
          language: "es",
          prompt: "Transcribe este mensaje de voz en español para una conversación con una IA llamada Lucy.",
        });
        if ("error" in result) throw new Error(result.error);
        return { text: result.text };
      }),
  }),
});

export type AppRouter = typeof appRouter;
