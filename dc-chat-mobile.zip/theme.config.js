/** @type {const} */
const themeColors = {
  primary: { light: '#a000e0', dark: '#c000ff' },
  background: { light: '#f5f1fb', dark: '#06050b' },
  surface: { light: '#ffffff', dark: '#100d1a' },
  foreground: { light: '#211b2d', dark: '#f5efff' },
  muted: { light: '#71667e', dark: '#aaa1bc' },
  border: { light: '#d8cce6', dark: '#35264e' },
  success: { light: '#15966a', dark: '#51f6b4' },
  warning: { light: '#b87500', dark: '#ffd166' },
  error: { light: '#d9365d', dark: '#ff5577' },
};

module.exports = { themeColors };
