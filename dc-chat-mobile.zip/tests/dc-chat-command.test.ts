import { describe, expect, it } from "vitest";
import { extractCommand, isCommandRequest } from "../shared/dc-chat-command";

describe("DC Chat command responses", () => {
  it("detects command-oriented prompts", () => {
    expect(isCommandRequest("Dame el comando para instalar Expo")).toBe(true);
    expect(isCommandRequest("Cuéntame una historia corta")).toBe(false);
  });

  it("extracts only the fenced command", () => {
    expect(extractCommand("Aquí tienes:\n```bash\npnpm expo install expo-clipboard\n```")).toBe("pnpm expo install expo-clipboard");
  });

  it("removes prose and keeps pure commands without a fenced block", () => {
    expect(extractCommand("Claro, ejecuta esto:\nnpm install expo-speech\nDespués reinicia la app.")).toBe("npm install expo-speech");
    expect(extractCommand("Comando:\ncd app && pnpm test")).toBe("cd app && pnpm test");
  });
});
