import { describe, expect, it } from "vitest";
import { EMOTION_CYCLE } from "../shared/dc-chat-emotion";

describe("Lucy emotion priority", () => {
  it("prioritizes affirming, working, and no while retaining every emotion", () => {
    const count = (emotion: string) => EMOTION_CYCLE.filter((value) => value === emotion).length;
    expect(count("affirming")).toBeGreaterThan(count("smile"));
    expect(count("working")).toBeGreaterThan(count("laugh"));
    expect(count("no")).toBeGreaterThan(count("neutral"));
    for (const emotion of ["smile", "laugh", "surprised", "affirming", "puedeser", "inventing", "playing", "working", "thinking", "angry", "no", "neutral"]) {
      expect(count(emotion)).toBeGreaterThan(0);
    }
  });
});
