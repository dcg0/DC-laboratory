import { describe, expect, it } from "vitest";
import { appRouter } from "../server/routers";
import type { TrpcContext } from "../server/_core/context";

function createContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("voice.transcribe", () => {
  it("rejects audio payloads that are too short before touching storage", async () => {
    const caller = appRouter.createCaller(createContext());

    await expect(
      caller.voice.transcribe({ audioBase64: "not-a-real-audio", mimeType: "audio/m4a" }),
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
