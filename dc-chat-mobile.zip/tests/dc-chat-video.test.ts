import { describe, expect, it } from "vitest";
import { VIDEO_PATHS, videoPathForEmotion } from "../shared/dc-chat-video";

describe("DC Chat emotional videos", () => {
  it("defines a storage path for every supplied expression", () => {
    const expected = [
      "neutral",
      "smile",
      "laugh",
      "angry",
      "surprised",
      "thinking",
      "affirming",
      "no",
      "puedeser",
      "working",
      "inventing",
      "playing",
    ] as const;

    expect(Object.keys(VIDEO_PATHS)).toHaveLength(expected.length);
    for (const emotion of expected) {
      expect(videoPathForEmotion(emotion)).toMatch(/^\/manus-storage\/.*\.mp4$/);
    }
  });

  it("uses nada.mp4 as the continuous idle state", () => {
    expect(VIDEO_PATHS.neutral).toMatch(/\/nada_[^/]+\.mp4$/);
  });
});
