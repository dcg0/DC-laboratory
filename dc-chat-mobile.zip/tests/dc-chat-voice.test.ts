import { describe, expect, it } from "vitest";
import { pickSpanishFemaleVoice } from "../shared/dc-chat-voice";

describe("Lucy voice selection", () => {
  it("prefers a Spanish feminine voice", () => {
    expect(pickSpanishFemaleVoice([
      { identifier: "es-MX-male", language: "es-MX", name: "Spanish Male" },
      { identifier: "es-MX-female", language: "es-MX", name: "Spanish Female" },
    ])).toBe("es-MX-female");
  });

  it("falls back to the first Spanish voice when metadata has no gender", () => {
    expect(pickSpanishFemaleVoice([
      { identifier: "en-US-voice", language: "en-US", name: "English" },
      { identifier: "es-ES-voice", language: "es-ES", name: "Español" },
    ])).toBe("es-ES-voice");
  });
});
