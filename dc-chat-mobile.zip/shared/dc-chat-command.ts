const COMMAND_LINE = /^(?:\s*[>$]\s*)?(?:npm|pnpm|yarn|bun|git|curl|wget|python(?:3)?|pip(?:3)?|node|npx|tsx|docker|kubectl|ssh|scp|chmod|chown|cp|mv|rm|mkdir|touch|cat|echo|export|source|sudo|apt(?:-get)?|brew|cd|set|New-Item|Invoke-WebRequest|Install-Module|const|let|var|function|import|export)\b/i;

export function isCommandRequest(input: string): boolean {
  return /comando|código|codigo|script|terminal|consola|cmd|bash|powershell|npm|pnpm|yarn|git\s|curl\s|python|javascript|typescript|instala|ejecuta|crear archivo/i.test(input);
}

export function extractCommand(text: string): string {
  const fenced = text.match(/```(?:bash|sh|shell|cmd|powershell|javascript|js|typescript|ts|python|py)?\s*([\s\S]*?)```/i);
  if (fenced?.[1]?.trim()) return fenced[1].trim().replace(/^\s*\$\s?/gm, "");

  const cleaned = text
    .replace(/^\s*(?:Aquí tienes|Claro,? aquí está|Por supuesto|Comando|Código)\s*:?\s*/i, "")
    .replace(/^\s*```[a-z]*\s*/i, "")
    .replace(/\s*```\s*$/i, "")
    .trim();
  const lines = cleaned.split(/\r?\n/);
  const firstCommand = lines.findIndex((line) => COMMAND_LINE.test(line));
  if (firstCommand < 0) return cleaned;
  const commandLines: string[] = [];
  for (const line of lines.slice(firstCommand)) {
    if (!line.trim()) {
      if (commandLines.length) break;
      continue;
    }
    if (COMMAND_LINE.test(line) || /^\s+(?:--?[a-z]|[A-Za-z_][\w-]*=|&&|\|)/.test(line)) commandLines.push(line);
    else if (commandLines.length) break;
  }
  return commandLines.join("\n").replace(/^\s*[$>]\s?/gm, "").trim() || cleaned;
}
