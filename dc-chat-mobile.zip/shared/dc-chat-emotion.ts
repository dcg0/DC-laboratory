export const EMOTION_CYCLE = [
  "affirming", "working", "no", "affirming", "working", "no",
  "smile", "affirming", "thinking", "working", "surprised", "no",
  "laugh", "affirming", "inventing", "working", "angry", "no",
  "puedeser", "affirming", "playing", "working", "neutral", "no",
] as const;

export type Emotion = (typeof EMOTION_CYCLE)[number];
