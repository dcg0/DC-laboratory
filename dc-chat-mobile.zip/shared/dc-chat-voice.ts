export type AvailableVoice = { identifier: string; language?: string; name?: string };

export function pickSpanishFemaleVoice(voices: AvailableVoice[]): string | undefined {
  const spanishVoices = voices.filter((voice) => voice.language?.toLowerCase().startsWith("es"));
  const preferred = spanishVoices.find((voice) => /female|mujer|woman|paulina|monica|monserrat|elena|sofia|luciana|samantha/i.test(`${voice.name ?? ""} ${voice.identifier}`));
  return (preferred ?? spanishVoices[0] ?? voices.find((voice) => /female|mujer|woman/i.test(`${voice.name ?? ""} ${voice.identifier}`)) ?? voices[0])?.identifier;
}
