export const VIDEO_PATHS = {
  neutral: "/manus-storage/nada_ae3b8e01.mp4",
  smile: "/manus-storage/feliz_8f911e7a.mp4",
  laugh: "/manus-storage/feliz_8f911e7a.mp4",
  angry: "/manus-storage/enojada_5b8487a1.mp4",
  surprised: "/manus-storage/desorientada_d7390e83.mp4",
  thinking: "/manus-storage/pensando_552fcfe8.mp4",
  affirming: "/manus-storage/afirmando_7cc788de.mp4",
  no: "/manus-storage/no_012b7c8c.mp4",
  puedeser: "/manus-storage/puedeser_340b68aa.mp4",
  working: "/manus-storage/trabajandoen_83c77372.mp4",
  inventing: "/manus-storage/inventando_51fd897d.mp4",
  playing: "/manus-storage/jugando_b810345b.mp4",
} as const;

export type VideoEmotion = keyof typeof VIDEO_PATHS;

export function videoPathForEmotion(emotion: VideoEmotion): string {
  return VIDEO_PATHS[emotion];
}
