Coloca aquí tus videos MP4 de Lucy/DC. La app usa esta carpeta como espacio reservado para futuras expresiones animadas.

Nombres recomendados:
- normal.mp4
- feliz.mp4
- enojada.mp4
- sorprendida.mp4
- pensando.mp4
- riendo.mp4

Cuando los agregues, vuelve a comprimir la carpeta completa y pásamela para integrar el cambio visual por emoción.

La app funciona sin videos usando el arte incluido como fallback.
