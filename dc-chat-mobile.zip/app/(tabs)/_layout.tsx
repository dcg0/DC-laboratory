import { Tabs } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Platform } from "react-native";

import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 8 : Math.max(insets.bottom, 8);
  return (
    <Tabs screenOptions={{
      tabBarActiveTintColor: colors.tint,
      headerShown: false,
      tabBarButton: HapticTab,
      tabBarStyle: { display: "none", backgroundColor: colors.background, borderTopColor: colors.border, paddingBottom: bottomPadding },
    }}>
      <Tabs.Screen name="index" options={{ title: "DC Chat", tabBarIcon: ({ color }) => <IconSymbol size={28} name="house.fill" color={color} /> }} />
    </Tabs>
  );
}
