import { useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import * as DocumentPicker from "expo-document-picker";
import * as Haptics from "expo-haptics";
import * as Clipboard from "expo-clipboard";
import * as FileSystem from "expo-file-system/legacy";
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from "expo-audio";
import { VideoView, useVideoPlayer } from "expo-video";
import * as Speech from "expo-speech";

import { ScreenContainer } from "@/components/screen-container";
import { getApiBaseUrl } from "@/constants/oauth";
import { trpc } from "@/lib/trpc";
import { VIDEO_PATHS } from "@/shared/dc-chat-video";
import { extractCommand, isCommandRequest } from "@/shared/dc-chat-command";
import { EMOTION_CYCLE, type Emotion } from "@/shared/dc-chat-emotion";
import { pickSpanishFemaleVoice } from "@/shared/dc-chat-voice";
const avatarSource = require("../../assets/images/lucy-logo.jpg");
type Role = "user" | "assistant";
type Provider = "manus" | "ollama" | "compatible";
type Message = { id: string; role: Role; content: string; emotion?: Emotion; attachment?: string; isCommand?: boolean; commandText?: string };
const FALLBACK_MODELS = ["gpt-5-mini", "claude-haiku-4-5", "gemini-3-flash-preview"];


const emotionMeta: Record<Emotion, { label: string; color: string; icon: string }> = {
  neutral: { label: "NEUTRAL", color: "#9ba1a6", icon: "◉" },
  smile: { label: "SMILE", color: "#f4a5ff", icon: "✦" },
  laugh: { label: "LAUGH", color: "#ffd166", icon: "✦" },
  angry: { label: "ANGRY", color: "#ff5577", icon: "!" },
  surprised: { label: "SURPRISED", color: "#62e6ff", icon: "?" },
  thinking: { label: "THINKING", color: "#a98bff", icon: "…" },
  affirming: { label: "AFFIRMING", color: "#6dffca", icon: "✓" },
  no: { label: "NO", color: "#ff5577", icon: "×" },
  puedeser: { label: "MAYBE", color: "#e0b4ff", icon: "?" },
  working: { label: "WORKING", color: "#62e6ff", icon: "◌" },
  inventing: { label: "INVENTING", color: "#ff9adf", icon: "✧" },
  playing: { label: "PLAYING", color: "#ffd166", icon: "♣" },
};

function detectEmotion(text: string): Emotion {
  const value = text.toLowerCase();
  if (/jugar|jugando|juego|divert/.test(value)) return "playing";
  if (/invent|crear|creativ|idea|imagina/.test(value)) return "inventing";
  if (/trabaj|proces|tarea|cargando/.test(value)) return "working";
  if (/quizá|quiza|tal vez|puede ser|depende/.test(value)) return "puedeser";
  if (/^no\b|\bno\b|prohibido|negativo/.test(value)) return "no";
  if (/sí|si|exacto|correcto|confirmado|afirmativo/.test(value)) return "affirming";
  if (/jaja|jeje|lol|xd|risa|😂|🤣/.test(value)) return "laugh";
  if (/error|fallo|no funciona|peligro|enoj|molest|basta|imposible/.test(value)) return "angry";
  if (/wow|increíble|sorpr|asombro|en serio|!!|😮|🤯/.test(value)) return "surprised";
  if (/[?]|quizá|tal vez|depende|analicemos|hmm|mmm/.test(value)) return "thinking";
  if (/hola|buenas|gracias|genial|perfecto|claro|✨|😊/.test(value)) return "smile";
  return "neutral";
}

function localReply(input: string): string {
  const emotion = detectEmotion(input);
  const replies: Record<Emotion, string[]> = {
    neutral: ["Entiendo. Dime más y lo resolvemos juntos.", "Sigo escuchándote. ¿Qué necesitas?"],
    smile: ["¡Claro que sí! Me encanta ayudarte ✨", "Estoy feliz de hablar contigo."],
    laugh: ["Jajaja, esa energía me gusta. 😄", "Me has hecho reír. Continúa, te escucho."],
    angry: ["Parece que algo falló. Vamos a revisarlo con calma.", "Detecto una alerta. Cuéntame qué ocurrió."],
    surprised: ["¡Wow! Eso sí que es interesante.", "No me lo esperaba. Vamos a explorar esa idea."],
    thinking: ["Déjame analizarlo…", "Mmm, hay varias posibilidades. Voy a pensarlo contigo."],
    affirming: ["Así es, tienes toda la razón. ✅", "Confirmado, vamos por buen camino."],
    no: ["No puedo hacer eso, pero sí puedo ayudarte de otra forma.", "Eso no es posible en este momento."],
    puedeser: ["Puede ser. Hay que revisar algunos detalles.", "Es una posibilidad interesante."],
    working: ["Estoy trabajando en ello…", "Procesando tu solicitud."],
    inventing: ["Tengo una idea nueva para eso. ✧", "Vamos a crear algo diferente."],
    playing: ["¡Vamos a jugar! ♣", "Eso suena divertido."],
  };
  return replies[emotion][Math.floor(Math.random() * replies[emotion].length)];
}

export default function HomeScreen() {
  const [messages, setMessages] = useState<Message[]>([
    { id: "welcome", role: "assistant", content: "¡Hola! Soy Lucy. ¿En qué puedo ayudarte hoy?", emotion: "neutral" },
  ]);
  const [draft, setDraft] = useState("");
  const [attachment, setAttachment] = useState<{ name: string; text?: string } | null>(null);
  const [provider, setProvider] = useState<Provider>("manus");
  const [model, setModel] = useState("gpt-5-mini");
  const [showProviders, setShowProviders] = useState(false);
  const [showModels, setShowModels] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [lightMode, setLightMode] = useState(false);
  const [soundOn, setSoundOn] = useState(true);
  const [femaleVoice, setFemaleVoice] = useState<string | undefined>();
  const [isThinking, setIsThinking] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [copiedCommandId, setCopiedCommandId] = useState<string | null>(null);
  const emotionCursor = useRef(0);
  const lastAssistantEmotion = useRef<Emotion>("neutral");
  const lastSpokenMessageId = useRef<string | null>(null);
  const audioRecorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(audioRecorder);
  const activeEmotion: Emotion = isThinking ? "thinking" : messages[messages.length - 1]?.emotion ?? "neutral";
  const activeResponse = messages[messages.length - 1]?.content ?? "¡Hola! Soy Lucy. ¿En qué puedo ayudarte hoy?";
  const activeMessage = messages[messages.length - 1];
  const videoUri = `${getApiBaseUrl()}${VIDEO_PATHS[activeEmotion]}`;
  const videoPlayerA = useVideoPlayer(videoUri, (player) => {
    player.loop = true;
    player.muted = true;
    player.play();
  });
  const videoPlayerB = useVideoPlayer(videoUri, (player) => {
    player.loop = true;
    player.muted = true;
    player.play();
  });
  const activeVideoLayer = useRef<0 | 1>(0);
  const videoOpacityA = useRef(new Animated.Value(1)).current;
  const videoOpacityB = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const nextPlayer = activeVideoLayer.current === 0 ? videoPlayerB : videoPlayerA;
    const nextOpacity = activeVideoLayer.current === 0 ? videoOpacityB : videoOpacityA;
    const previousOpacity = activeVideoLayer.current === 0 ? videoOpacityA : videoOpacityB;
    let cancelled = false;
    void nextPlayer.replaceAsync(videoUri).then(() => {
      if (cancelled) return;
      nextPlayer.currentTime = 0;
      nextPlayer.play();
      Animated.parallel([
        Animated.timing(nextOpacity, { toValue: 1, duration: 180, useNativeDriver: true }),
        Animated.timing(previousOpacity, { toValue: 0, duration: 180, useNativeDriver: true }),
      ]).start();
      activeVideoLayer.current = activeVideoLayer.current === 0 ? 1 : 0;
    });
    return () => { cancelled = true; };
  }, [activeEmotion, videoOpacityA, videoOpacityB, videoPlayerA, videoPlayerB, videoUri]);
  const avatarScale = useRef(new Animated.Value(1)).current;
  const avatarLift = useRef(new Animated.Value(0)).current;
  const copyPulse = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    const pulse = Animated.loop(Animated.sequence([
      Animated.timing(copyPulse, { toValue: 0.48, duration: 650, useNativeDriver: true }),
      Animated.timing(copyPulse, { toValue: 1, duration: 650, useNativeDriver: true }),
    ]));
    pulse.start();
    return () => pulse.stop();
  }, [copyPulse]);

  useEffect(() => {
    const isThinkingEmotion = activeEmotion === "thinking";
    const pulse = isThinkingEmotion
      ? Animated.loop(
          Animated.sequence([
            Animated.timing(avatarScale, { toValue: 1.06, duration: 520, useNativeDriver: true }),
            Animated.timing(avatarScale, { toValue: 0.98, duration: 520, useNativeDriver: true }),
          ]),
        )
      : Animated.parallel([
          Animated.spring(avatarScale, { toValue: activeEmotion === "surprised" ? 1.09 : activeEmotion === "angry" ? 1.03 : 1.0, useNativeDriver: true, speed: 18, bounciness: 7 }),
          Animated.sequence([
            Animated.timing(avatarLift, { toValue: activeEmotion === "laugh" || activeEmotion === "smile" ? -9 : 3, duration: 160, useNativeDriver: true }),
            Animated.timing(avatarLift, { toValue: 0, duration: 260, useNativeDriver: true }),
          ]),
        ]);
    pulse.start();
    return () => pulse.stop();
  }, [activeEmotion, avatarLift, avatarScale]);

  const modelsQuery = trpc.ai.models.useQuery(undefined, { staleTime: 60_000 });
  const chatMutation = trpc.ai.chat.useMutation();
  const voiceMutation = trpc.voice.transcribe.useMutation();
  const models = modelsQuery.data?.length ? modelsQuery.data : FALLBACK_MODELS;

  useEffect(() => {
    void requestRecordingPermissionsAsync();
    void setAudioModeAsync({ playsInSilentMode: true, allowsRecording: true });
  }, []);
  useEffect(() => {
    void Speech.getAvailableVoicesAsync().then((voices) => {
      setFemaleVoice(pickSpanishFemaleVoice(voices));
    }).catch(() => undefined);
  }, []);
  useEffect(() => {
    const latest = messages[messages.length - 1];
    if (!soundOn || !latest || latest.role !== "assistant" || latest.id === lastSpokenMessageId.current) return;
    lastSpokenMessageId.current = latest.id;
    const spokenText = latest.content.replace(/```[a-z]*\n?/gi, "").replace(/```/g, "").trim().slice(0, 3500);
    if (!spokenText) return;
    void Speech.stop().then(() => {
      Speech.speak(spokenText, { language: "es-MX", voice: femaleVoice, rate: 0.96, pitch: 1.08 });
    });
  }, [femaleVoice, messages, soundOn]);

  const palette = useMemo(
    () =>
      lightMode
        ? { background: "#f5f1fb", surface: "#ffffff", card: "#eee7f7", text: "#211b2d", muted: "#71667e", border: "#d8cce6" }
        : { background: "#06050b", surface: "#100d1a", card: "#171126", text: "#f5efff", muted: "#aaa1bc", border: "#35264e" },
    [lightMode],
  );

  const providerName = provider === "manus" ? "Manus AI" : provider === "ollama" ? "Ollama local" : "OpenAI compatible";

  const sendMessage = async (voiceText?: string) => {
    const clean = (voiceText ?? draft).trim();
    if (!clean || isThinking) return;
    if (Platform.OS !== "web") await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    const composed = attachment?.text ? `${clean}\n\n[Archivo adjunto: ${attachment.name}]\n${attachment.text.slice(0, 5000)}` : clean;
    const commandRequest = isCommandRequest(clean);
    const userMessage: Message = { id: `${Date.now()}-u`, role: "user", content: clean, attachment: attachment?.name };
    setMessages((current) => [...current, userMessage]);
    setDraft("");
    setAttachment(null);
    setIsThinking(true);

    try {
      let content = "";
      if (provider === "manus") {
        const history = [...messages, userMessage].map((message) => ({ role: message.role, content: message.content }));
        const result = await chatMutation.mutateAsync({ model, messages: history });
        content = result.content;
      } else if (provider === "ollama") {
        content = `${localReply(composed)}\n\nModo local listo: conecta Ollama en tu red para sustituir esta respuesta de demostración.`;
      } else {
        content = "El adaptador OpenAI-compatible está listo para conectar tu endpoint desde la configuración segura del proyecto.";
      }
      const rawContent = content || localReply(clean);
      const commandText = commandRequest ? extractCommand(rawContent) : undefined;
      const detectedResponseEmotion = detectEmotion(rawContent);
      const inputRequestsWork = /trabaj|proces|tarea|cargando|ejecuta|hazlo|resuelve|genera|crea/.test(clean.toLowerCase());
      const inputRequestsNo = /no quiero|no hagas|rechaza|prohib|evita|cancel|detén|deten|no puedes/.test(clean.toLowerCase());
      const inputConfirms = /confirma|acepta|sí|si |correcto|exacto|aprueba|de acuerdo/.test(clean.toLowerCase());
      const semanticEmotion = inputRequestsNo ? "no" : inputRequestsWork ? "working" : inputConfirms ? "affirming" : detectedResponseEmotion;
      const shouldRotate = detectedResponseEmotion === "neutral" || detectedResponseEmotion === "smile" || detectedResponseEmotion === lastAssistantEmotion.current;
      const responseEmotion = semanticEmotion !== "neutral" && semanticEmotion !== "smile" ? semanticEmotion : shouldRotate ? EMOTION_CYCLE[emotionCursor.current++ % EMOTION_CYCLE.length] : semanticEmotion;
      lastAssistantEmotion.current = responseEmotion;
      setMessages((current) => [...current, { id: `${Date.now()}-a`, role: "assistant", content: commandText ?? rawContent, commandText, isCommand: commandRequest, emotion: responseEmotion }]);
    } catch {
      const fallbackEmotion = EMOTION_CYCLE[emotionCursor.current++ % EMOTION_CYCLE.length];
      lastAssistantEmotion.current = fallbackEmotion;
      setMessages((current) => [...current, { id: `${Date.now()}-fallback`, role: "assistant", content: `${localReply(clean)}\n\nNo pude contactar al proveedor ahora; cambié a una respuesta local segura.`, emotion: fallbackEmotion }]);
    } finally {
      setIsThinking(false);
    }
  };

  const toggleVoice = async () => {
    if (recorderState.isRecording) {
      await audioRecorder.stop();
      const uri = audioRecorder.uri;
      if (!uri) return;
      setIsTranscribing(true);
      try {
        const audioBase64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
        const result = await voiceMutation.mutateAsync({ audioBase64, mimeType: "audio/m4a" });
        await sendMessage(result.text);
      } catch {
        setMessages((current) => [...current, { id: `${Date.now()}-voice-error`, role: "assistant", content: "No pude transcribir el audio. Revisa el permiso del micrófono e inténtalo otra vez.", emotion: "angry" }]);
      } finally {
        setIsTranscribing(false);
      }
      return;
    }
    const permission = await requestRecordingPermissionsAsync();
    if (!permission.granted) {
      setMessages((current) => [...current, { id: `${Date.now()}-voice-permission`, role: "assistant", content: "Necesito permiso para usar el micrófono y convertir tu voz en texto.", emotion: "thinking" }]);
      return;
    }
    await audioRecorder.prepareToRecordAsync();
    audioRecorder.record();
  };

  const pickAttachment = async () => {
    const result = await DocumentPicker.getDocumentAsync({ type: ["text/*", "application/pdf", "application/json"], copyToCacheDirectory: true });
    if (result.canceled) return;
    const asset = result.assets[0];
    let text: string | undefined;
    if (asset.mimeType?.startsWith("text/") || asset.name.endsWith(".json")) {
      try {
        text = await fetch(asset.uri).then((response) => response.text());
      } catch {
        text = undefined;
      }
    }
    setAttachment({ name: asset.name, text });
  };

  const copyCommand = async (id: string, command: string) => {
    await Clipboard.setStringAsync(command);
    setCopiedCommandId(id);
    setTimeout(() => setCopiedCommandId((current) => current === id ? null : current), 1800);
  };

  const renderMessage = ({ item }: { item: Message }) => {
    const assistant = item.role === "assistant";
    const emotion = item.emotion ?? "neutral";
    return (
      <View style={[styles.messageRow, assistant ? styles.left : styles.right]}>
        {assistant && <Image source={avatarSource} style={styles.miniAvatar} />}
        <View style={[styles.bubble, assistant ? { backgroundColor: palette.card, borderColor: palette.border } : styles.userBubble]}>
          <Text style={[styles.messageText, { color: assistant ? palette.text : "#ffffff" }]}>{item.content}</Text>
          {assistant && item.isCommand && item.commandText && <Animated.View style={{ opacity: copyPulse }}><Pressable onPress={() => void copyCommand(item.id, item.commandText!)} style={({ pressed }) => [styles.copyCommandButton, copiedCommandId === item.id && styles.copyCommandButtonActive, pressed && styles.pressed]}><Text style={styles.copyCommandText}>{copiedCommandId === item.id ? "✓ COPIADO" : "⧉ COPIAR COMANDO"}</Text></Pressable></Animated.View>}
          {item.attachment && <Text style={styles.attachmentLabel}>◫ {item.attachment}</Text>}
          {assistant && <Text style={[styles.emotionLabel, { color: emotionMeta[emotion].color }]}>{emotionMeta[emotion].icon} {emotionMeta[emotion].label}</Text>}
        </View>
      </View>
    );
  };

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} style={{ backgroundColor: palette.background }}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={[styles.header, { borderBottomColor: palette.border, backgroundColor: palette.background }]}>
          <Pressable onPress={() => setShowMenu(true)} style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}><Text style={styles.headerIcon}>☰</Text></Pressable>
          <View style={styles.titleWrap}><Text style={styles.title}>DC <Text style={styles.titleAccent}>_</Text> LUCY</Text><Text style={[styles.subtitle, { color: palette.muted }]}>NEURAL COMPANION</Text></View>
          <View style={styles.headerRight}><Image source={avatarSource} style={styles.headerAvatar} /></View>
        </View>

        <View style={styles.statusBar}><View style={styles.onlineDot} /><Text style={styles.onlineText}>ONLINE</Text><View style={styles.statusDivider} /><Text style={[styles.providerText, { color: palette.muted }]}>{providerName}</Text><View style={styles.modelPill}><Text style={styles.modelText}>{model}</Text></View></View>

        <View style={styles.avatarStage}>
          <Animated.View style={[styles.videoLayer, { opacity: videoOpacityA }]}><VideoView player={videoPlayerA} style={styles.fullscreenVideo} contentFit="cover" nativeControls={false} /></Animated.View>
          <Animated.View style={[styles.videoLayer, { opacity: videoOpacityB }]}><VideoView player={videoPlayerB} style={styles.fullscreenVideo} contentFit="cover" nativeControls={false} /></Animated.View>
          <View style={styles.imageShade} />
          <View style={styles.overlayTextWrap}><ScrollView style={styles.overlayTextScroll} contentContainerStyle={styles.overlayTextContent} showsVerticalScrollIndicator={true}><Text style={styles.overlayText}>{isThinking ? "Déjame pensar…" : activeResponse}</Text>{activeMessage?.isCommand && activeMessage.commandText && <Animated.View style={{ opacity: copyPulse }}><Pressable onPress={() => void copyCommand(activeMessage.id, activeMessage.commandText!)} style={({ pressed }) => [styles.copyCommandButton, styles.overlayCopyButton, copiedCommandId === activeMessage.id && styles.copyCommandButtonActive, pressed && styles.pressed]}><Text style={styles.copyCommandText}>{copiedCommandId === activeMessage.id ? "✓ COPIADO" : "⧉ COPIAR COMANDO"}</Text></Pressable></Animated.View>}</ScrollView></View>
          <View style={[styles.avatarTag, { borderColor: emotionMeta[activeEmotion].color }]}><Text style={[styles.avatarTagText, { color: emotionMeta[activeEmotion].color }]}>◉ {isThinking ? "THINKING" : emotionMeta[activeEmotion].label}</Text></View>
        </View>

        {(isThinking || isTranscribing) && <View style={styles.thinkingRow}><ActivityIndicator color="#c000ff" size="small" /><Text style={styles.thinkingText}>{isTranscribing ? "Transcribiendo tu voz…" : "Lucy está procesando…"}</Text></View>}


        <View style={[styles.composer, { backgroundColor: palette.surface, borderColor: palette.border }]}>
          {attachment && <View style={styles.attachmentChip}><Text style={styles.attachmentText}>◫ {attachment.name}</Text><Pressable onPress={() => setAttachment(null)}><Text style={styles.removeAttachment}>×</Text></Pressable></View>}
          <View style={styles.composerRow}><TextInput value={draft} onChangeText={setDraft} onSubmitEditing={() => void sendMessage()} returnKeyType="send" placeholder="Enviar mensaje…" placeholderTextColor={palette.muted} style={[styles.input, { color: palette.text }]} /><Pressable onPress={() => void sendMessage()} style={({ pressed }) => [styles.sendButton, pressed && styles.sendPressed]}><Text style={styles.sendIcon}>➤</Text></Pressable></View></View>

      </KeyboardAvoidingView>

      <Modal visible={showMenu} transparent animationType="slide" onRequestClose={() => setShowMenu(false)}><Pressable style={styles.drawerBackdrop} onPress={() => setShowMenu(false)}><View style={[styles.drawer, { backgroundColor: palette.surface, borderRightColor: palette.border }]}><ScrollView showsVerticalScrollIndicator={false}><View style={styles.drawerHeader}><Text style={[styles.drawerTitle, { color: palette.text }]}>MENÚ DE LUCY</Text><Pressable onPress={() => setShowMenu(false)} style={styles.drawerClose}><Text style={styles.drawerCloseText}>×</Text></Pressable></View><Text style={[styles.drawerHint, { color: palette.muted }]}>Todas las funciones en un solo lugar</Text><Text style={styles.drawerSection}>ACCIONES RÁPIDAS</Text><Pressable onPress={() => { setDraft("Dame una respuesta rápida sobre "); setShowMenu(false); }} style={styles.drawerItem}><Text style={styles.drawerIcon}>ϟ</Text><Text style={styles.drawerItemText}>Respuesta rápida</Text></Pressable><Pressable onPress={() => { setDraft("Ayúdame a completar esta tarea: "); setShowMenu(false); }} style={styles.drawerItem}><Text style={styles.drawerIcon}>▣</Text><Text style={styles.drawerItemText}>Iniciar tarea</Text></Pressable><Pressable onPress={() => { setShowProviders(true); setShowMenu(false); }} style={styles.drawerItem}><Text style={styles.drawerIcon}>✧</Text><Text style={styles.drawerItemText}>Creación de IA</Text></Pressable><Text style={styles.drawerSection}>ENTRADA Y CHAT</Text><Pressable onPress={() => void toggleVoice()} style={[styles.drawerItem, recorderState.isRecording && styles.drawerItemActive]}><Text style={styles.drawerIcon}>{recorderState.isRecording ? "■" : "♩"}</Text><Text style={styles.drawerItemText}>{recorderState.isRecording ? "Detener grabación" : "Mensaje de voz"}</Text></Pressable><Pressable onPress={() => void pickAttachment()} style={styles.drawerItem}><Text style={styles.drawerIcon}>◫</Text><Text style={styles.drawerItemText}>Adjuntar archivo</Text></Pressable><Text style={styles.drawerSection}>CONFIGURACIÓN</Text><Pressable onPress={() => { setShowModels(true); setShowMenu(false); }} style={styles.drawerItem}><Text style={styles.drawerIcon}>◈</Text><Text style={styles.drawerItemText}>Modelo: {model}</Text></Pressable><Pressable onPress={() => { setShowProviders(true); setShowMenu(false); }} style={styles.drawerItem}><Text style={styles.drawerIcon}>◎</Text><Text style={styles.drawerItemText}>Proveedor: {providerName}</Text></Pressable><Pressable onPress={() => setLightMode((value) => !value)} style={styles.drawerItem}><Text style={styles.drawerIcon}>◐</Text><Text style={styles.drawerItemText}>{lightMode ? "Tema oscuro" : "Tema claro"}</Text></Pressable><Pressable onPress={() => setSoundOn((value) => !value)} style={styles.drawerItem}><Text style={styles.drawerIcon}>{soundOn ? "◖" : "◌"}</Text><Text style={styles.drawerItemText}>{soundOn ? "Silenciar interfaz" : "Activar sonido"}</Text></Pressable><Pressable onPress={() => { setMessages([{ id: "welcome-reset", role: "assistant", content: "Memoria de sesión reiniciada. ¿Qué exploramos ahora?", emotion: "neutral" }]); setShowMenu(false); }} style={styles.drawerItem}><Text style={styles.drawerIcon}>↺</Text><Text style={styles.drawerItemText}>Reiniciar conversación</Text></Pressable></ScrollView></View></Pressable></Modal>
      <Modal visible={showProviders} transparent animationType="fade" onRequestClose={() => setShowProviders(false)}><Pressable style={styles.modalBackdrop} onPress={() => setShowProviders(false)}><View style={[styles.modalCard, { backgroundColor: palette.surface, borderColor: palette.border }]}><Text style={styles.modalEyebrow}>CONNECTION HUB</Text><Text style={[styles.modalTitle, { color: palette.text }]}>Elige tu IA</Text><Text style={[styles.modalDescription, { color: palette.muted }]}>La interfaz se mantiene igual aunque cambies de proveedor.</Text>{([{ id: "manus", label: "Manus AI", detail: "Catálogo integrado y seguro" }, { id: "ollama", label: "Ollama local", detail: "Privado, offline en tu red" }, { id: "compatible", label: "OpenAI compatible", detail: "Adaptador para tu endpoint" }] as const).map((option) => <Pressable key={option.id} onPress={() => { setProvider(option.id); setShowProviders(false); }} style={({ pressed }) => [styles.option, provider === option.id && styles.optionActive, pressed && styles.pressed]}><View><Text style={styles.optionTitle}>{option.label}</Text><Text style={styles.optionDetail}>{option.detail}</Text></View><Text style={styles.optionMark}>{provider === option.id ? "●" : "○"}</Text></Pressable>)}<Pressable onPress={() => setShowProviders(false)} style={styles.closeButton}><Text style={styles.closeButtonText}>CERRAR</Text></Pressable></View></Pressable></Modal>

      <Modal visible={showModels} transparent animationType="fade" onRequestClose={() => setShowModels(false)}><Pressable style={styles.modalBackdrop} onPress={() => setShowModels(false)}><View style={[styles.modalCard, { backgroundColor: palette.surface, borderColor: palette.border }]}><Text style={styles.modalEyebrow}>MODEL ROUTER</Text><Text style={[styles.modalTitle, { color: palette.text }]}>Modelo activo</Text>{models.map((availableModel) => <Pressable key={availableModel} onPress={() => { setModel(availableModel); setShowModels(false); }} style={({ pressed }) => [styles.option, model === availableModel && styles.optionActive, pressed && styles.pressed]}><Text style={styles.optionTitle}>{availableModel}</Text><Text style={styles.optionMark}>{model === availableModel ? "●" : "○"}</Text></Pressable>)}<Pressable onPress={() => setShowModels(false)} style={styles.closeButton}><Text style={styles.closeButtonText}>CERRAR</Text></Pressable></View></Pressable></Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  header: { height: 64, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 18, borderBottomWidth: 1 },
  iconButton: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  headerIcon: { color: "#ffffff", fontSize: 23 },
  pressed: { opacity: 0.65 },
  titleWrap: { alignItems: "center" },
  title: { color: "#ffffff", fontSize: 19, fontWeight: "800", letterSpacing: 3 },
  titleAccent: { color: "#c000ff" },
  subtitle: { color: "#8e839e", fontSize: 8, letterSpacing: 2.2, marginTop: 4 },
  statusBar: { height: 40, flexDirection: "row", alignItems: "center", paddingHorizontal: 20, gap: 7 },
  onlineDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#51f6b4" },
  onlineText: { color: "#51f6b4", fontSize: 9, fontWeight: "800", letterSpacing: 1.2 },
  statusDivider: { width: 1, height: 14, backgroundColor: "#3c2a53", marginHorizontal: 4 },
  providerText: { fontSize: 10, flex: 1 },
  modelPill: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: "#231837", borderRadius: 10, paddingHorizontal: 9, paddingVertical: 5 },
  modelText: { color: "#dca8ff", fontSize: 9, fontWeight: "700" },
  chevron: { color: "#dca8ff", fontSize: 13 },
  avatarStage: { flex: 1, minHeight: 250, alignItems: "center", justifyContent: "center", overflow: "hidden" },
  fullscreenAvatar: { position: "absolute", width: "100%", height: "100%" },
  fullscreenVideo: { position: "absolute", width: "100%", height: "100%" },
  videoLayer: { ...StyleSheet.absoluteFillObject },
  videoLoading: { ...StyleSheet.absoluteFillObject, alignItems: "center", justifyContent: "center", backgroundColor: "#05030a" },
  imageShade: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(0, 0, 0, 0.22)" },
  overlayTextWrap: { position: "absolute", left: 24, right: 24, top: "39%", maxHeight: 190 },
  overlayTextScroll: { maxHeight: 190 },
  overlayTextContent: { alignItems: "center", paddingVertical: 4 },
  overlayText: { color: "#ffffff", fontSize: 15, lineHeight: 21, textAlign: "center", textShadowColor: "rgba(0,0,0,0.9)", textShadowOffset: { width: 1, height: 2 }, textShadowRadius: 8 },
  copyCommandButton: { marginTop: 10, alignSelf: "flex-start", borderRadius: 10, borderWidth: 1, borderColor: "#d66aff", backgroundColor: "rgba(32, 8, 48, 0.92)", paddingHorizontal: 11, paddingVertical: 7 },
  overlayCopyButton: { alignSelf: "center" },
  copyCommandButtonActive: { backgroundColor: "#6b168c", borderColor: "#f2bcff" },
  copyCommandText: { color: "#f2c7ff", fontSize: 10, fontWeight: "800", letterSpacing: 0.7 },
  avatarGlow: { position: "absolute", width: 290, height: 290, borderRadius: 145, backgroundColor: "#8a00ff", opacity: 0.13 },
  avatar: { width: 250, height: 250, borderRadius: 125, borderWidth: 2, borderColor: "#c000ff" },
  avatarTag: { position: "absolute", bottom: 5, backgroundColor: "#0e0a17", borderColor: "#c000ff", borderWidth: 1, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4 },
  avatarTagText: { color: "#e0a7ff", fontSize: 9, fontWeight: "800", letterSpacing: 1.1 },
  messagesViewport: { maxHeight: 164, flexGrow: 0 },
  headerRight: { flexDirection: "row", alignItems: "center", gap: 11 },
  headerAvatar: { width: 43, height: 43, borderRadius: 22, borderWidth: 1, borderColor: "#c000ff" },
  soundButton: { width: 30, alignItems: "center" },
  soundIcon: { color: "#62bfff", fontSize: 29, transform: [{ rotate: "-20deg" }] },
  quickBar: { flexDirection: "row", gap: 9, paddingHorizontal: 14, paddingBottom: 7 },
  quickAction: { flex: 1, minHeight: 40, borderRadius: 11, borderWidth: 1, borderColor: "#3b2852", backgroundColor: "rgba(10, 7, 17, 0.88)", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, paddingHorizontal: 7 },
  quickIcon: { color: "#ffffff", fontSize: 15 },
  quickLabel: { color: "#ffffff", fontSize: 9, fontWeight: "800" },
  quickArrow: { color: "#ffffff", fontSize: 17 },
  messageList: { paddingHorizontal: 17, paddingBottom: 8, gap: 11 },
  messageRow: { flexDirection: "row", alignItems: "flex-end", gap: 8 },
  left: { justifyContent: "flex-start" },
  right: { justifyContent: "flex-end" },
  miniAvatar: { width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: "#c000ff" },
  bubble: { maxWidth: "82%", borderRadius: 17, borderWidth: 1, paddingHorizontal: 13, paddingVertical: 10 },
  userBubble: { backgroundColor: "#7300a6", borderBottomRightRadius: 4 },
  messageText: { fontSize: 14, lineHeight: 20 },
  emotionLabel: { fontSize: 8, fontWeight: "800", letterSpacing: 1.1, marginTop: 7 },
  attachmentLabel: { color: "#f0c7ff", fontSize: 10, marginTop: 6 },
  thinkingRow: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 55, paddingVertical: 4 },
  thinkingText: { color: "#a99bb8", fontSize: 11, fontStyle: "italic" },
  composer: { marginHorizontal: 14, marginTop: 6, marginBottom: 8, borderRadius: 18, borderWidth: 1, paddingHorizontal: 10, paddingTop: 7, paddingBottom: 7 },
  composerRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  input: { flex: 1, minHeight: 40, fontSize: 15 },
  attachButton: { width: 34, height: 34, alignItems: "center", justifyContent: "center" },
  attachIcon: { color: "#bba8ca", fontSize: 24, transform: [{ rotate: "-45deg" }] },
  recordingButton: { backgroundColor: "#5b1235", borderRadius: 17 },
  recordingIcon: { color: "#ff5577", transform: [{ rotate: "0deg" }] },
  sendButton: { width: 38, height: 38, borderRadius: 19, backgroundColor: "#a000e0", alignItems: "center", justifyContent: "center" },
  sendPressed: { transform: [{ scale: 0.94 }], opacity: 0.85 },
  sendIcon: { color: "#ffffff", fontSize: 17 },
  attachmentChip: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: "#241438", borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6, marginBottom: 6 },
  attachmentText: { color: "#edc9ff", fontSize: 10, flex: 1 },
  removeAttachment: { color: "#ff8fba", fontSize: 18, paddingLeft: 8 },
  bottomBar: { height: 59, borderTopWidth: 1, flexDirection: "row", alignItems: "center", justifyContent: "space-around" },
  bottomAction: { alignItems: "center", gap: 2, minWidth: 70 },
  bottomIcon: { color: "#c000ff", fontSize: 21 },
  bottomLabel: { fontSize: 8, letterSpacing: 1.3, fontWeight: "700" },
  modalBackdrop: { flex: 1, backgroundColor: "rgba(3, 1, 7, 0.8)", justifyContent: "center", padding: 22 },
  modalCard: { borderRadius: 24, borderWidth: 1, padding: 22 },
  drawerBackdrop: { flex: 1, backgroundColor: "rgba(3, 1, 7, 0.72)" },
  drawer: { width: 305, maxWidth: "86%", flex: 1, borderRightWidth: 1, paddingTop: 52, paddingHorizontal: 20, paddingBottom: 22 },
  drawerHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  drawerTitle: { fontSize: 18, fontWeight: "900", letterSpacing: 1.5 },
  drawerClose: { width: 34, height: 34, borderRadius: 17, backgroundColor: "#291237", alignItems: "center", justifyContent: "center" },
  drawerCloseText: { color: "#f2c7ff", fontSize: 24, lineHeight: 26 },
  drawerHint: { fontSize: 11, marginTop: 7, marginBottom: 22 },
  drawerSection: { color: "#c000ff", fontSize: 10, fontWeight: "900", letterSpacing: 1.4, marginTop: 15, marginBottom: 7 },
  drawerItem: { minHeight: 47, borderRadius: 12, flexDirection: "row", alignItems: "center", paddingHorizontal: 12, marginBottom: 6, backgroundColor: "rgba(16, 8, 26, 0.76)" },
  drawerItemActive: { borderWidth: 1, borderColor: "#ff5d96", backgroundColor: "rgba(91, 17, 51, 0.8)" },
  drawerIcon: { width: 30, color: "#e3a2ff", fontSize: 18, textAlign: "center", marginRight: 7 },
  drawerItemText: { color: "#ffffff", fontSize: 13, fontWeight: "700", flex: 1 },
  modalEyebrow: { color: "#c000ff", fontSize: 10, letterSpacing: 2, fontWeight: "800" },
  modalTitle: { fontSize: 25, fontWeight: "800", marginTop: 8 },
  modalDescription: { fontSize: 13, lineHeight: 19, marginTop: 8, marginBottom: 14 },
  option: { minHeight: 56, borderRadius: 14, borderWidth: 1, borderColor: "#3a2851", paddingHorizontal: 14, paddingVertical: 10, marginTop: 9, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  optionActive: { borderColor: "#c000ff", backgroundColor: "#271239" },
  optionTitle: { color: "#ffffff", fontSize: 14, fontWeight: "700" },
  optionDetail: { color: "#a99bb8", fontSize: 11, marginTop: 3 },
  optionMark: { color: "#e399ff", fontSize: 18 },
  closeButton: { alignItems: "center", paddingVertical: 14, marginTop: 8 },
  closeButtonText: { color: "#c000ff", fontSize: 11, letterSpacing: 1.4, fontWeight: "800" },
});
